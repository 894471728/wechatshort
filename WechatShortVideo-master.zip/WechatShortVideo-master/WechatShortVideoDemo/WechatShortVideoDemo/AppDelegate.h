//
//  AppDelegate.h
//  WechatShortVideoDemo
//
//  Created by AliThink on 15/8/19.
//  Copyright (c) 2015年 AliThink. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

