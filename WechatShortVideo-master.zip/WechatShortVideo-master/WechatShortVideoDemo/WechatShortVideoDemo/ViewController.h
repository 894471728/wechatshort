//
//  ViewController.h
//  WechatShortVideoDemo
//
//  Created by AliThink on 15/8/19.
//  Copyright (c) 2015年 AliThink. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

